
const express = require('express')
const app = express()

app.get('/', (req, res) => {
  res.send('ONLINE')
})

app.listen(3000, () => {
  console.log(`Express is online`)
})
const Discord = require("discord.js");
const ttdl =  require("tiktok-video-downloader");
const https = require("https");

const { Client, Intents, MessageActionRow, MessageButton, MessageEmbed, MessageSelectMenu, messageCreate, EmbedBuilder, WebhookClient, ButtonBuilder, ActionRowBuilder,MessageAttachment, Modal, TextInputComponent ,SelectMenuComponent, showModal} = require("discord.js");



const client = new Client({
  intents: [
      Intents.FLAGS.GUILDS,
      Intents.FLAGS.GUILD_MEMBERS,
      Intents.FLAGS.GUILD_BANS,
      Intents.FLAGS.GUILD_INTEGRATIONS,
      Intents.FLAGS.GUILD_WEBHOOKS,
      Intents.FLAGS.GUILD_INVITES,
      Intents.FLAGS.GUILD_VOICE_STATES,
      Intents.FLAGS.GUILD_PRESENCES,
      Intents.FLAGS.GUILD_MESSAGES,
      Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
      Intents.FLAGS.GUILD_MESSAGE_TYPING,
      Intents.FLAGS.DIRECT_MESSAGES,
      Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
      Intents.FLAGS.DIRECT_MESSAGE_TYPING,
  ],
allowedMentions: {
  parse: ["everyone", "roles", "users"],
  repliedUser: true
},
});
const logs = new WebhookClient({ url: 'https://discord.com/api/webhooks/1105214248210145323/OLmg3AEY0LX43tJG39rgkQUnHD8AVXJVqtAwRWZBrOBT0-PwgDZe-REPwBjkVfzWegTs' });

client.on('ready', () =>{
  console.log(client.user.tag + ' ready')
})
const prefix = "!";
client.on('messageCreate', async (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'تحميل') {
    if (!args[0]) {
      return message.reply('يرجى تقديم رابط فيديو TikTok.');
    }
message.delete()
    const videoUrl = args[0];
  ttdl.getInfo(videoUrl)
  .then((result) => {
 https.get(result.video.url.no_wm, (response) => {
          const chunks = [];
          response.on('data', (chunk) => chunks.push(chunk));
          response.on('end', () => {
            const buffer = Buffer.concat(chunks);
            const attachment = new Discord.MessageAttachment(buffer, 'video.mp4');
message.reply({ content: "**تم ارسل في الشات المعين الفيديو**"});

           return logs.send({ content: `**التحميل من تبع: ${message.author}** `, files: [attachment], ephemeral: true});
          });

  })
  });
  }
})


client.on('error', error => console.log(error));
client.on('warn', info => console.log(info));
process.on('unhandledRejection', (reason, p) => {
console.log(reason.stack ? reason.stack : reason)
return;

});
process.on("uncaughtException", (err, origin) => {
console.log(err.stack ? err.stack : err)
return;

}) 
process.on('uncaughtExceptionMonitor', (err, origin) => {
console.log(err.stack ? err.stack : err)
return;
});



/////.   message.reply({ content: "**تم ارسل في الشات المعين الفيديو**",  ephemeral: true});

client.login("MTEwNDQzMjAyMDQwNDMyNjQ4MQ.G7IYIJ.40qelSIpct8IloszHvJJrmXqP3NiXAMgPYdpSQ")